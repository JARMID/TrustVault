import React, { Suspense, lazy, useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Crosshair, Shield, Activity, Zap } from 'lucide-react';

/**
 * SecurityGlobe — Ultra-Premium 3D Interactable Render
 * Powered by Spline's "Particle Planet".
 * Features dynamic HUD tracking, click interactions, and live telemetry simulation.
 */

const Spline = lazy(() => import('@splinetool/react-spline'));

// Spline scene URL
const SPLINE_SCENE_URL = 'https://prod.spline.design/6Wq1Q7YGyM-iab9i/scene.splinecode';

const CSSFallbackOrb: React.FC = () => (
  <div className="w-full h-full flex items-center justify-center relative">
    <div className="absolute w-[420px] h-[420px] rounded-full" style={{ background: 'radial-gradient(circle, rgba(59,130,246,0.15) 0%, rgba(59,130,246,0.05) 40%, transparent 70%)', animation: 'pulse-glow 4s ease-in-out infinite' }} />
    <div className="absolute w-[320px] h-[320px] rounded-full border border-blue-500/10 animate-[spin_30s_linear_infinite]" />
    <div className="absolute w-[260px] h-[260px] rounded-full border border-blue-500/5 animate-[spin_20s_linear_infinite_reverse]" />
    <div className="w-[200px] h-[200px] rounded-full" style={{ background: 'radial-gradient(circle at 35% 35%, rgba(96,165,250,0.25), rgba(59,130,246,0.1) 50%, rgba(2,6,23,0.9) 80%)', boxShadow: '0 0 60px rgba(59,130,246,0.2), inset 0 0 60px rgba(59,130,246,0.1)', animation: 'float 6s ease-in-out infinite' }} />
  </div>
);

const SecurityGlobe: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [activeNodes, setActiveNodes] = useState<number>(3);
  const [telemetry, setTelemetry] = useState({ lat: 0, lng: 0, status: 'STABLE' });

  // Simulate telemetry noise
  useEffect(() => {
    if (!isLoaded) return;
    const interval = setInterval(() => {
      setTelemetry({
        lat: (Math.random() * 180 - 90).toFixed(4) as any,
        lng: (Math.random() * 360 - 180).toFixed(4) as any,
        status: Math.random() > 0.9 ? 'SCANNING' : 'SECURE'
      });
      if (Math.random() > 0.8) setActiveNodes((prev) => (prev % 8) + 1);
    }, 2000);
    return () => clearInterval(interval);
  }, [isLoaded]);

  const handleGlobeClick = () => {
    setIsScanning(true);
    setTimeout(() => setIsScanning(false), 800);
  };

  return (
    <div
      ref={containerRef}
      className="w-full h-full relative overflow-hidden flex items-center justify-center group"
    >
      {/* Background Atmosphere */}
      <div className="absolute inset-0 pointer-events-none z-0" style={{ background: 'radial-gradient(ellipse at 50% 50%, rgba(59,130,246,0.08) 0%, transparent 60%)' }} />

      {/* 3D Spline Layer */}
      {hasError ? (
        <CSSFallbackOrb />
      ) : (
        <Suspense fallback={<CSSFallbackOrb />}>
          <div className="w-[120%] h-[120%] xl:w-[140%] xl:h-[140%] absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 transition-opacity duration-1000" style={{ opacity: isLoaded ? 1 : 0 }}>
            <Spline
              scene={SPLINE_SCENE_URL}
              onLoad={() => setIsLoaded(true)}
              onError={() => setHasError(true)}
              onMouseDown={handleGlobeClick}
              className="w-full h-full cursor-crosshair"
            />
          </div>
        </Suspense>
      )}

      {/* Interactive Data Overlays */}
      <AnimatePresence>
        {isLoaded && (
          <>
            {/* Top Left: Active Node Count */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="absolute top-1/4 left-10 lg:left-24 z-20 pointer-events-none flex items-center gap-3"
            >
              <div className="w-12 h-12 rounded-full border border-blue-500/30 flex items-center justify-center bg-black/40 backdrop-blur-md relative">
                <div className="absolute inset-0 rounded-full border-t border-brand-primary animate-spin" style={{ animationDuration: '3s' }} />
                <Activity size={20} className="text-brand-primary" />
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-brand-primary font-mono tracking-widest leading-none mb-1">NODES_ONLINE</span>
                <span className="text-2xl font-bold text-white tracking-widest">
                  {activeNodes.toString().padStart(2, '0')}<span className="text-brand-primary/50 text-sm">/08</span>
                </span>
              </div>
            </motion.div>

            {/* Bottom Right: Live Telemetry */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="absolute bottom-1/4 right-10 lg:right-24 z-20 pointer-events-none"
            >
              <div className="bg-black/60 backdrop-blur-xl border border-white/10 rounded-xl p-4 min-w-[200px] shadow-[0_0_30px_rgba(59,130,246,0.15)]">
                <div className="flex items-center gap-2 mb-3 pb-2 border-b border-white/5">
                  <Shield size={14} className={telemetry.status === 'SECURE' ? 'text-success' : 'text-warning'} />
                  <span className="text-[10px] font-mono tracking-wider text-white/50">SECTOR ALPHA</span>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between font-mono text-xs">
                    <span className="text-brand-primary/50">LAT</span>
                    <span className="text-white">{telemetry.lat}</span>
                  </div>
                  <div className="flex justify-between font-mono text-xs">
                    <span className="text-brand-primary/50">LNG</span>
                    <span className="text-white">{telemetry.lng}</span>
                  </div>
                  <div className="flex justify-between font-mono text-xs mt-2 pt-2 border-t border-white/5">
                    <span className="text-brand-primary/50">SYS</span>
                    <span className={`font-bold ${telemetry.status === 'SECURE' ? 'text-success' : 'text-warning'} animate-pulse`}>
                      {telemetry.status}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Center Reticle (Shows on interaction) */}
            <motion.div 
              className="absolute inset-0 pointer-events-none z-30 flex items-center justify-center"
              initial={false}
              animate={{ 
                scale: isScanning ? 1.5 : 1,
                opacity: isScanning ? 1 : 0.3 
              }}
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
            >
              <div className="w-[400px] h-[400px] rounded-full border-[0.5px] border-brand-primary/20 relative flex items-center justify-center">
                <Crosshair size={40} className="text-brand-primary/30 absolute opacity-50" strokeWidth={1} />
                {isScanning && (
                  <motion.div 
                    initial={{ scale: 0.8, opacity: 1 }}
                    animate={{ scale: 2, opacity: 0 }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="absolute w-full h-full rounded-full border border-brand-primary"
                  />
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SecurityGlobe;

