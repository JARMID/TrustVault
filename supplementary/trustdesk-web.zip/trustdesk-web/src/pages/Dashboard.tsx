import React, { useState, useEffect } from 'react';
import { ShieldAlert, AlertTriangle, Users, ArrowUpRight, ArrowDownRight, Clock, MapPin, Shield, TrendingUp, Zap, Eye, BarChart3, Activity } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell, BarChart, Bar } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../components/ui/Toast';

const initialTimelineData = [
  { name: '00:00', alerts: 8, panic: 1, resolved: 6 },
  { name: '04:00', alerts: 5, panic: 0, resolved: 4 },
  { name: '08:00', alerts: 12, panic: 2, resolved: 9 },
  { name: '10:00', alerts: 18, panic: 5, resolved: 11 },
  { name: '12:00', alerts: 15, panic: 1, resolved: 14 },
  { name: '14:00', alerts: 25, panic: 8, resolved: 16 },
  { name: '16:00', alerts: 22, panic: 4, resolved: 19 },
  { name: '18:00', alerts: 30, panic: 12, resolved: 21 },
  { name: '20:00', alerts: 14, panic: 3, resolved: 12 },
  { name: '22:00', alerts: 10, panic: 2, resolved: 9 },
];

const severityData = [
  { name: 'Critical', value: 12, color: '#EF4444' },
  { name: 'High', value: 28, color: '#F59E0B' },
  { name: 'Medium', value: 45, color: '#3B82F6' },
  { name: 'Low', value: 67, color: '#6366F1' },
];

const initialEvents = [
  { id: 'INC-4201', type: 'Unauth Access', location: 'Science Wing, Bldg 4', severity: 'CRITICAL', time: '3 min ago', subject: 'ID-88492' },
  { id: 'INC-4200', type: 'Protest Crowd', location: 'Main Quad', severity: 'HIGH', time: '12 min ago', subject: 'Group 50+' },
  { id: 'INC-4199', type: 'Fire Alarm', location: 'Dorm Block B', severity: 'CRITICAL', time: '18 min ago', subject: 'Sensor 1A' },
  { id: 'INC-4198', type: 'Vandalism', location: 'Library, Floor 2', severity: 'MEDIUM', time: '24 min ago', subject: 'Cam 42' },
  { id: 'INC-4197', type: 'Noise Complaint', location: 'Student Center', severity: 'LOW', time: '31 min ago', subject: 'Room 204' },
  { id: 'INC-4196', type: 'Suspicious Package', location: 'Admin Building', severity: 'HIGH', time: '45 min ago', subject: 'Mailroom' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 300, damping: 24 } }
};

const StatCard: React.FC<{
  title: string;
  value: string | number;
  trend: string;
  trendUp: boolean;

  icon: React.ReactNode;
  variant?: 'danger' | 'warning' | 'primary' | 'success';
  subtitle?: string;
}> = ({ title, value, trend, trendUp, icon, variant = 'primary', subtitle }) => {
  const getColors = () => {
    switch(variant) {
      case 'danger': return { bg: 'rgba(239, 68, 68, 0.08)', color: '#EF4444', glow: 'rgba(239, 68, 68, 0.15)' };
      case 'warning': return { bg: 'rgba(245, 158, 11, 0.08)', color: '#F59E0B', glow: 'rgba(245, 158, 11, 0.15)' };
      case 'success': return { bg: 'rgba(16, 185, 129, 0.08)', color: '#10B981', glow: 'rgba(16, 185, 129, 0.15)' };
      default: return { bg: 'rgba(59, 130, 246, 0.08)', color: '#3B82F6', glow: 'rgba(59, 130, 246, 0.15)' };
    }
  };
  const colors = getColors();

  return (
    <motion.div 
      variants={itemVariants}
      className="glass-card relative overflow-hidden group cursor-pointer"
      whileHover={{ y: -4, scale: 1.01 }}
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
      style={{ padding: '20px 24px' }}
    >
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity" style={{ background: `linear-gradient(135deg, ${colors.bg} 0%, transparent 100%)`, transitionDuration: '500ms' }}/>
      <div className="absolute top-0 right-0 w-32 h-32 opacity-[0.03] group-hover:opacity-[0.06] transition-opacity" style={{ background: `radial-gradient(circle, ${colors.color}, transparent 70%)`, transitionDuration: '500ms' }}/>
      
      <div className="flex justify-between items-start mb-3 relative z-10">
        <div style={{
          width: '44px', height: '44px', borderRadius: '12px',
          background: colors.bg, border: `1px solid ${colors.glow}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: colors.color
        }}>
          {icon}
        </div>
        <div className={`flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full`}
          style={{ 
            background: trendUp ? 'rgba(239, 68, 68, 0.1)' : 'rgba(16, 185, 129, 0.1)',
            color: trendUp ? '#F87171' : '#34D399'
          }}
        >
          {trendUp ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
          {trend}
        </div>
      </div>
      <h3 style={{ fontSize: '1.75rem', fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.1, marginBottom: '4px' }} className="relative z-10">{value}</h3>
      <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 500 }} className="relative z-10">{title}</p>
      {subtitle && <p style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)', marginTop: '4px', fontFamily: 'monospace' }} className="relative z-10">{subtitle}</p>}
    </motion.div>
  );
};

const getSeverityBadge = (severity: string) => {
  const map: Record<string, string> = {
    CRITICAL: 'bg-red-500/10 text-red-400 border-red-500/20',
    HIGH: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    MEDIUM: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    LOW: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  };
  return map[severity] || '';
};

const Dashboard: React.FC = () => {
  const { addToast } = useToast();
  
  // Real-time Simulation State
  const [timelineData, setTimelineData] = useState(initialTimelineData);
  const [recentEvents, setRecentEvents] = useState(initialEvents);
  const [activeQueue, setActiveQueue] = useState(23);
  const [weeklyData] = useState([
    { day: 'Mon', incidents: 42 },
    { day: 'Tue', incidents: 38 },
    { day: 'Wed', incidents: 55 },
    { day: 'Thu', incidents: 47 },
    { day: 'Fri', incidents: 62 },
    { day: 'Sat', incidents: 31 },
    { day: 'Sun', incidents: 24 },
  ]);

  // Simulate incoming SOC data
  useEffect(() => {
    const interval = setInterval(() => {
      setTimelineData(prev => {
        const newData = [...prev];
        const last = { ...newData[newData.length - 1] };
        if (Math.random() > 0.5) {
          last.alerts += Math.floor(Math.random() * 3);
          last.resolved += Math.floor(Math.random() * 2);
          newData[newData.length - 1] = last;
        }
        return newData;
      });
      
      if (Math.random() > 0.7) {
        setActiveQueue(prev => prev + (Math.random() > 0.5 ? 1 : -1));
      }
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="show"
      style={{ maxWidth: '1440px', margin: '0 auto' }}
    >
      {/* Header */}
      <div className="flex justify-between items-end mb-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-h1">Security Overview</h1>
            <div className="flex items-center gap-2 px-3 py-1 rounded-full" style={{ background: 'rgba(16, 185, 129, 0.1)', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
              <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#10B981', boxShadow: '0 0 8px #10B981', animation: 'pulse 2s infinite' }} />
              <span style={{ fontSize: '0.7rem', fontWeight: 600, color: '#34D399', letterSpacing: '0.05em' }}>LIVE</span>
            </div>
          </div>
          <p className="text-sm" style={{ maxWidth: '500px' }}>Real-time monitoring hub for campus threats, community signals, and triage operations across all zones.</p>
        </div>
        <div className="flex gap-3">
          <motion.button 
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="btn btn-ghost"
            style={{ border: '1px solid var(--border-strong)', borderRadius: '10px' }}
          >
            <Clock size={16} /> Last 24h
          </motion.button>
          <motion.button 
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="btn btn-primary" 
            style={{ borderRadius: '10px' }}
            onClick={() => addToast({ type: 'success', title: 'Report generating', message: 'Your security report is being compiled. This may take a moment.' })}
          >
            <BarChart3 size={16} /> Generate Report
          </motion.button>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <StatCard title="Active Incidents" value="152" trend="+14%" trendUp={true} icon={<AlertTriangle size={22} />} variant="danger" subtitle="12 critical in queue" />
        <StatCard title="Access Restrictions" value="1,284" trend="+5.2%" trendUp={true} icon={<ShieldAlert size={22} />} variant="primary" subtitle="42 active card blocks" />
        <StatCard title="Avg Response Time" value="14.5m" trend="-8.3%" trendUp={false} icon={<Zap size={22} />} variant="success" subtitle="Target: < 15m ✓" />
        <StatCard title="Community Signals" value="3,847" trend="+22%" trendUp={true} icon={<Users size={22} />} variant="warning" subtitle="156 unverified" />
      </div>

      {/* Charts Row */}
      <div className="grid gap-6 mb-8" style={{ gridTemplateColumns: '1fr 320px' }}>
        {/* Main Chart */}
        <motion.div variants={itemVariants} className="glass-card" style={{ padding: '24px' }}>
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="text-h3" style={{ marginBottom: '4px' }}>Threat Activity Timeline</h3>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-tertiary)' }}>24-hour incident velocity across all monitored zones</p>
            </div>
            <div className="flex gap-4 items-center">
              <div className="flex items-center gap-2">
                <div style={{ width: '10px', height: '3px', borderRadius: '2px', background: '#3B82F6' }} />
                <span style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)' }}>Alerts</span>
              </div>
              <div className="flex items-center gap-2">
                <div style={{ width: '10px', height: '3px', borderRadius: '2px', background: '#EF4444' }} />
                <span style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)' }}>Panic</span>
              </div>
              <div className="flex items-center gap-2">
                <div style={{ width: '10px', height: '3px', borderRadius: '2px', background: '#10B981' }} />
                <span style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)' }}>Resolved</span>
              </div>
            </div>
          </div>
          <div style={{ height: '280px', width: '100%' }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={timelineData}>
                <defs>
                  <linearGradient id="gradAlerts" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="gradPanic" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EF4444" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="gradResolved" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748B', fontSize: 11}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748B', fontSize: 11}} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(11, 14, 20, 0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '10px', boxShadow: '0 8px 32px rgba(0,0,0,0.4)' }}
                  itemStyle={{ color: '#fff', fontSize: '12px' }}
                  labelStyle={{ color: '#94A3B8', fontSize: '11px', marginBottom: '4px' }}
                />
                <Area type="monotone" dataKey="resolved" stroke="#10B981" strokeWidth={2} fillOpacity={1} fill="url(#gradResolved)" />
                <Area type="monotone" dataKey="alerts" stroke="#3B82F6" strokeWidth={2.5} fillOpacity={1} fill="url(#gradAlerts)" />
                <Area type="monotone" dataKey="panic" stroke="#EF4444" strokeWidth={2.5} fillOpacity={1} fill="url(#gradPanic)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Severity Breakdown */}
        <motion.div variants={itemVariants} className="glass-card" style={{ padding: '24px' }}>
          <h3 className="text-h3" style={{ marginBottom: '4px' }}>Severity Distribution</h3>
          <p style={{ fontSize: '0.8rem', color: 'var(--text-tertiary)', marginBottom: '16px' }}>Active incident breakdown</p>
          <div style={{ height: '160px', width: '100%' }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={severityData}
                  cx="50%" cy="50%"
                  innerRadius={48} outerRadius={72}
                  paddingAngle={4}
                  dataKey="value"
                  stroke="none"
                >
                  {severityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(11, 14, 20, 0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-col gap-2" style={{ marginTop: '8px' }}>
            {severityData.map((item) => (
              <div key={item.name} className="flex items-center justify-between" style={{ padding: '6px 0' }}>
                <div className="flex items-center gap-2">
                  <div style={{ width: '8px', height: '8px', borderRadius: '2px', background: item.color }} />
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{item.name}</span>
                </div>
                <span style={{ fontSize: '0.8rem', fontWeight: 600, fontFamily: 'monospace', color: 'var(--text-primary)' }}>{item.value}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Bottom Row */}
      <div className="grid gap-6" style={{ gridTemplateColumns: '1fr 340px' }}>
        {/* Advanced Triage Kanban Board */}
        <motion.div variants={itemVariants} className="glass-card" style={{ padding: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--border-subtle)' }} className="flex justify-between items-center">
            <div>
              <h3 className="text-h3" style={{ marginBottom: '2px' }}>Advanced Triage Board</h3>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>Drag and drop incidents across stages</p>
            </div>
            <button className="btn btn-ghost" style={{ fontSize: '0.75rem', padding: '6px 14px', border: '1px solid var(--border-strong)', borderRadius: '8px' }}>
              <Eye size={14} /> View Details
            </button>
          </div>
          
          <div style={{ display: 'flex', flex: 1, padding: '16px', gap: '16px', overflowX: 'auto' }}>
            {['Open', 'In Progress', 'Resolved'].map(status => {
              const columnEvents = recentEvents.filter(e => {
                if (status === 'Open') return !e.status || e.status === 'Open';
                return e.status === status;
              });

              return (
                <div 
                  key={status}
                  style={{ flex: 1, minWidth: '250px', background: 'rgba(0,0,0,0.2)', borderRadius: '12px', padding: '12px', display: 'flex', flexDirection: 'column', gap: '12px' }}
                  onDragOver={(e) => { e.preventDefault(); e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; }}
                  onDragLeave={(e) => { e.currentTarget.style.background = 'rgba(0,0,0,0.2)'; }}
                  onDrop={(e) => {
                    e.preventDefault();
                    e.currentTarget.style.background = 'rgba(0,0,0,0.2)';
                    const id = e.dataTransfer.getData('text/plain');
                    setRecentEvents(prev => prev.map(ev => ev.id === id ? { ...ev, status } : ev));
                  }}
                >
                  <div className="flex justify-between items-center px-1">
                    <span style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-secondary)' }}>{status}</span>
                    <span style={{ fontSize: '0.7rem', background: 'rgba(255,255,255,0.1)', padding: '2px 8px', borderRadius: '12px', color: 'var(--text-tertiary)' }}>{columnEvents.length}</span>
                  </div>
                  
                  <div className="flex flex-col gap-2 flex-1">
                    <AnimatePresence>
                      {columnEvents.map((event) => (
                        <motion.div
                          key={event.id}
                          layout
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          draggable
                          onDragStart={(e) => {
                            e.dataTransfer.setData('text/plain', event.id);
                            e.currentTarget.style.opacity = '0.5';
                          }}
                          onDragEnd={(e) => {
                            e.currentTarget.style.opacity = '1';
                          }}
                          style={{
                            background: 'var(--bg-surface)',
                            border: '1px solid var(--border-subtle)',
                            borderRadius: '8px',
                            padding: '12px',
                            cursor: 'grab'
                          }}
                          className="hover:bg-white/5 transition-colors"
                        >
                          <div className="flex justify-between items-start mb-2">
                            <span style={{ fontSize: '0.75rem', fontFamily: 'monospace', color: 'var(--brand-primary)', fontWeight: 600 }}>{event.id}</span>
                            <span className={`text-[9px] font-bold px-2 py-0.5 rounded border ${getSeverityBadge(event.severity)}`}>
                              {event.severity}
                            </span>
                          </div>
                          <h4 style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '4px' }}>{event.type}</h4>
                          <div className="flex items-center gap-1 mb-2" style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                            <MapPin size={10} /> {event.location}
                          </div>
                          <div className="flex justify-between items-center pt-2 mt-2" style={{ borderTop: '1px solid var(--border-subtle)' }}>
                            <span style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)' }}>{event.subject}</span>
                            <div className="flex items-center gap-1" style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)' }}>
                              <Clock size={10} /> {event.time}
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Weekly Trend + Quick Stats */}
        <div className="flex flex-col gap-6">
          <motion.div variants={itemVariants} className="glass-card" style={{ padding: '20px 24px' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, marginBottom: '4px' }}>Weekly Trend</h3>
            <p style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginBottom: '16px' }}>Incidents per day</p>
            <div style={{ height: '120px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyData}>
                  <Bar dataKey="incidents" radius={[4, 4, 0, 0]}>
                    {weeklyData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={index === 4 ? '#3B82F6' : 'rgba(59, 130, 246, 0.25)'} />
                    ))}
                  </Bar>
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: '#64748B', fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: 'rgba(11, 14, 20, 0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                    itemStyle={{ color: '#fff', fontSize: '12px' }}
                    cursor={{ fill: 'rgba(255,255,255,0.03)' }}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Operational Metrics */}
          <motion.div variants={itemVariants} className="glass-card" style={{ padding: '20px 24px' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, marginBottom: '16px' }}>Operational Health</h3>
            <div className="flex flex-col gap-4">
              {[
                { label: 'System Uptime', value: '99.97%', icon: <Shield size={14} />, color: '#10B981' },
                { label: 'SLA Compliance', value: '98.2%', icon: <TrendingUp size={14} />, color: '#3B82F6' },
                { label: 'Queue Depth', value: `${activeQueue} items`, icon: <Activity size={14} className="animate-pulse" />, color: '#F59E0B' },
              ].map(metric => (
                <div key={metric.label} className="flex items-center justify-between" style={{ padding: '10px 12px', background: 'rgba(0,0,0,0.2)', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
                  <div className="flex items-center gap-3">
                    <div style={{ color: metric.color }}>{metric.icon}</div>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{metric.label}</span>
                  </div>
                  <span style={{ fontSize: '0.85rem', fontWeight: 700, fontFamily: 'monospace', color: metric.color }}>{metric.value}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};

export default Dashboard;
