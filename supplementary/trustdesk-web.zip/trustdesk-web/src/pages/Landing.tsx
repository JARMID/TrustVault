import React, { Suspense, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, useInView } from 'framer-motion';
import { Shield, Fingerprint, Lock, Activity, Zap, Globe, Eye, ChevronRight, ChevronDown, Cpu, Radar, Network, ShieldCheck, BarChart3, Bell } from 'lucide-react';
import { Canvas } from '@react-three/fiber';
import SecurityGlobe from '../components/3d/SecurityGlobe';

/* ---- Responsive CSS injected once ---- */
const landingStyles = `
  .landing-stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 32px;
  }
  .landing-features-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 24px;
  }
  .landing-platform-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 64px;
    align-items: center;
  }
  .landing-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 40px;
  }
  .landing-hero-content {
    max-width: 560px;
  }
  .landing-footer-inner {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
  }

  @media (max-width: 1024px) {
    .landing-features-grid {
      grid-template-columns: repeat(2, 1fr);
    }
    .landing-platform-grid {
      grid-template-columns: 1fr;
    }
  }
  @media (max-width: 768px) {
    .landing-stats-grid {
      grid-template-columns: repeat(2, 1fr);
      gap: 24px;
    }
    .landing-features-grid {
      grid-template-columns: 1fr;
    }
    .landing-container {
      padding: 0 20px;
    }
    .landing-footer-inner {
      flex-direction: column;
      text-align: center;
    }
  }
  @media (max-width: 480px) {
    .landing-hero-content {
      max-width: 100%;
    }
  }

  @keyframes pulse-glow {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }
  .feature-card {
    padding: 28px;
    border-radius: 16px;
    background: rgba(255,255,255,0.02);
    border: 1px solid rgba(255,255,255,0.06);
    transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    cursor: default;
  }
  .feature-card:hover {
    border-color: rgba(59, 130, 246, 0.3);
    background: rgba(59, 130, 246, 0.05);
    transform: translateY(-4px);
    box-shadow: 0 16px 48px rgba(0,0,0,0.4);
  }
  .cta-btn-primary {
    display: inline-flex;
    align-items: center;
    gap: 16px;
    padding: 16px 40px;
    border-radius: 12px;
    background: rgba(0, 0, 0, 0.5);
    border: 1px solid rgba(59, 130, 246, 0.3);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    color: white;
    cursor: pointer;
    transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
    font-size: 0.95rem;
    letter-spacing: 0.15em;
    font-weight: 500;
    position: relative;
    overflow: hidden;
  }
  .cta-btn-primary:hover {
    border-color: rgba(59, 130, 246, 0.7);
    box-shadow: 0 0 40px rgba(59, 130, 246, 0.2), 0 0 80px rgba(59, 130, 246, 0.05);
    background: rgba(59, 130, 246, 0.1);
  }
  .cta-btn-secondary {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 16px 24px;
    border-radius: 12px;
    background: transparent;
    border: 1px solid rgba(255,255,255,0.08);
    color: #94A3B8;
    cursor: pointer;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
    font-size: 0.85rem;
    transition: all 0.3s ease;
  }
  .cta-btn-secondary:hover {
    border-color: rgba(255,255,255,0.2);
    color: #fff;
  }
  .cta-btn-large {
    display: inline-flex;
    align-items: center;
    gap: 16px;
    padding: 20px 48px;
    border-radius: 12px;
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.15), rgba(59, 130, 246, 0.05));
    border: 1px solid rgba(59, 130, 246, 0.35);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    color: white;
    cursor: pointer;
    transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
    font-size: 1.05rem;
    letter-spacing: 0.12em;
    font-weight: 600;
  }
  .cta-btn-large:hover {
    border-color: rgba(59, 130, 246, 0.7);
    box-shadow: 0 0 60px rgba(59, 130, 246, 0.2);
    transform: translateY(-2px);
  }
  .terminal-preview {
    border-radius: 16px;
    padding: 4px;
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(59, 130, 246, 0.02));
    border: 1px solid rgba(59, 130, 246, 0.15);
  }
  .terminal-inner {
    border-radius: 12px;
    padding: 32px;
    background: rgba(2, 6, 23, 0.95);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
    font-size: 0.78rem;
    line-height: 1.8;
  }
`;

/* ---- Scroll-reveal wrapper ---- */
const Reveal: React.FC<{ children: React.ReactNode; delay?: number; style?: React.CSSProperties }> = ({ children, delay = 0, style }) => {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-60px' });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
      transition={{ duration: 0.7, delay, ease: [0.16, 1, 0.3, 1] }}
      style={style}
    >
      {children}
    </motion.div>
  );
};

const features = [
  { icon: <Radar size={22} />, title: 'Real-time Threat Monitoring', desc: 'Continuously scan all campus zones with AI-driven anomaly detection and instant alert escalation.' },
  { icon: <Network size={22} />, title: 'Global Threat Intelligence', desc: 'Aggregate threat feeds from 14,000+ nodes worldwide for proactive defense posture.' },
  { icon: <Zap size={22} />, title: 'Instant Incident Response', desc: 'Automated triage workflows with sub-15-minute SLA and one-click panic protocols.' },
  { icon: <ShieldCheck size={22} />, title: 'Zero-Trust Architecture', desc: 'End-to-end AES-256 encryption, role-based access, and continuous identity verification.' },
  { icon: <BarChart3 size={22} />, title: 'Advanced Analytics', desc: 'Interactive dashboards with severity distributions, trend analysis, and exportable reports.' },
  { icon: <Bell size={22} />, title: 'Smart Notifications', desc: 'Multi-channel alerts via Slack, PagerDuty, email, and SMS with intelligent de-duplication.' },
];

const stats = [
  { value: '99.97%', label: 'Uptime SLA' },
  { value: '<15m', label: 'Avg Response' },
  { value: '14,204', label: 'Active Nodes' },
  { value: '256-bit', label: 'Encryption' },
];

const Landing: React.FC = () => {
  const navigate = useNavigate();
  const featuresRef = useRef<HTMLDivElement>(null);

  return (
    <>
      <style>{landingStyles}</style>
      <div style={{ width: '100%', background: '#000', color: '#fff', overflowX: 'hidden' }}>

        {/* Global Fixed 3D Canvas */}
        <div style={{ position: 'fixed', inset: 0, zIndex: 0, background: '#000' }}>
          <Canvas 
            camera={{ position: [0, 0, 7], fov: 45 }}
            eventSource={document.getElementById('root') || undefined}
            eventPrefix="client"
          >
            <Suspense fallback={null}>
              <SecurityGlobe />
            </Suspense>
          </Canvas>
        </div>

        {/* Content Wrapper */}
        <div style={{ position: 'relative', zIndex: 10 }}>

          {/* ====== LANDING NAV ====== */}
          <motion.nav
            initial={{ y: -80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            style={{
              position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
              height: '64px',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '0 40px',
              background: 'rgba(0, 0, 0, 0.5)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              borderBottom: '1px solid rgba(255,255,255,0.05)',
            }}
          >
            {/* Logo */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }} onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(37, 99, 235, 0.1))',
                border: '1px solid rgba(59, 130, 246, 0.4)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                boxShadow: '0 0 12px rgba(59, 130, 246, 0.3)',
                overflow: 'hidden'
              }}>
                <img src="/logo3d.png" alt="TrustDesk Logo" style={{ width: '100%', height: '100%', objectFit: 'cover', transform: 'scale(1.2)' }} />
              </div>
              <span style={{ fontSize: '1rem', fontWeight: 700, letterSpacing: '-0.02em' }}>
                TRUST<span style={{ fontWeight: 300, color: '#60A5FA' }}>DESK</span>
              </span>
            </div>

            {/* Center Links */}
            <div style={{ display: 'flex', gap: 32, alignItems: 'center' }}>
              {[
                { label: 'Features', action: () => featuresRef.current?.scrollIntoView({ behavior: 'smooth' }) },
                { label: 'Platform', action: () => document.getElementById('platform-section')?.scrollIntoView({ behavior: 'smooth' }) },
                { label: 'Pricing', action: () => {} },
                { label: 'Docs', action: () => {} },
              ].map((link) => (
                <button
                  key={link.label}
                  onClick={link.action}
                  style={{
                    background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer',
                    fontSize: '0.82rem', fontWeight: 500, padding: '4px 0',
                    transition: 'color 0.2s',
                    fontFamily: 'inherit',
                  }}
                  onMouseOver={e => (e.currentTarget.style.color = '#fff')}
                  onMouseOut={e => (e.currentTarget.style.color = '#94A3B8')}
                >
                  {link.label}
                </button>
              ))}
            </div>

            {/* CTA Right */}
            <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
              <button
                onClick={() => navigate('/login')}
                style={{
                  background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer',
                  fontSize: '0.82rem', fontWeight: 500, padding: '8px 16px',
                  transition: 'color 0.2s', fontFamily: 'inherit',
                }}
                onMouseOver={e => (e.currentTarget.style.color = '#fff')}
                onMouseOut={e => (e.currentTarget.style.color = '#94A3B8')}
              >
                Sign In
              </button>
              <button
                onClick={() => navigate('/app/dashboard')}
                style={{
                  background: 'rgba(59, 130, 246, 0.1)',
                  border: '1px solid rgba(59, 130, 246, 0.3)',
                  borderRadius: 8, padding: '8px 20px',
                  color: '#60A5FA', cursor: 'pointer',
                  fontSize: '0.82rem', fontWeight: 600,
                  transition: 'all 0.3s', fontFamily: 'inherit',
                }}
                onMouseOver={e => { e.currentTarget.style.background = 'rgba(59, 130, 246, 0.2)'; e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.5)'; }}
                onMouseOut={e => { e.currentTarget.style.background = 'rgba(59, 130, 246, 0.1)'; e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.3)'; }}
              >
                Get Started
              </button>
            </div>
          </motion.nav>

          {/* ====== HERO SECTION ====== */}
          <section style={{ position: 'relative', minHeight: '100vh', display: 'flex', alignItems: 'center', overflow: 'hidden' }}>

          {/* Cyber Grid Overlay */}
          <div style={{
            position: 'absolute', inset: 0, zIndex: 1, pointerEvents: 'none',
            backgroundImage: `linear-gradient(rgba(59, 130, 246, 0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(59, 130, 246, 0.06) 1px, transparent 1px)`,
            backgroundSize: '60px 60px',
            opacity: 0.4,
          }} />

          {/* Vignette */}
          <div style={{ position: 'absolute', inset: 0, zIndex: 1, pointerEvents: 'none', background: 'radial-gradient(ellipse at 30% 50%, transparent 20%, rgba(0,0,0,0.8) 70%)' }} />
          {/* Bottom fade */}
          <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 1, pointerEvents: 'none', height: '120px', background: 'linear-gradient(transparent, rgba(2,6,23,0.6))' }} />

          {/* Hero Content */}
          <div className="landing-container" style={{ position: 'relative', zIndex: 10, width: '100%', paddingTop: '80px', paddingBottom: '80px' }}>
            <div className="landing-hero-content">
              {/* Logo mark */}
              <motion.div
                initial={{ opacity: 0, scale: 0.6 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
                style={{ marginBottom: '32px', position: 'relative', display: 'inline-block' }}
              >
                <div style={{ position: 'absolute', inset: 0, opacity: 0.3, filter: 'blur(48px)', borderRadius: '50%', background: '#3B82F6', transform: 'scale(3)' }} />
                <div style={{
                  width: '120px', height: '120px', borderRadius: '24px',
                  background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(59, 130, 246, 0.02))',
                  border: '1px solid rgba(59, 130, 246, 0.4)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  backdropFilter: 'blur(20px)',
                  boxShadow: '0 0 40px rgba(59, 130, 246, 0.15), inset 0 0 30px rgba(59, 130, 246, 0.05)',
                  position: 'relative',
                  overflow: 'hidden'
                }}>
                  <img src="/logo3d.png" alt="TrustDesk 3D Logo" style={{ width: '100%', height: '100%', objectFit: 'cover', transform: 'scale(1.15)' }} />
                </div>
              </motion.div>

              {/* Title */}
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
                style={{ fontSize: 'clamp(2.5rem, 5vw, 4rem)', fontWeight: 800, letterSpacing: '-0.04em', lineHeight: 1.05, marginBottom: '16px' }}
              >
                TRUST<span style={{ fontWeight: 300, color: '#60A5FA' }}>DESK</span>
              </motion.h1>

              {/* Subtitle */}
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5, duration: 1 }}
                style={{ fontSize: 'clamp(0.9rem, 1.5vw, 1.1rem)', color: '#94A3B8', fontFamily: 'monospace', lineHeight: 1.8, maxWidth: '520px', marginBottom: '40px' }}
              >
                Sovereign Security Operations &amp; Decentralized Threat Intelligence Platform.
                Monitor, detect, and respond — all from a single command center.
              </motion.p>

              {/* CTA Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              >
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', alignItems: 'center', marginBottom: '24px' }}>
                  <button className="cta-btn-primary" onClick={() => navigate('/app/dashboard')}>
                    <Fingerprint size={22} style={{ color: '#60A5FA' }} />
                    <span>INITIALIZE SYSTEM</span>
                    <ChevronRight size={18} style={{ color: '#60A5FA', opacity: 0.6 }} />
                  </button>
                  <button className="cta-btn-secondary" onClick={() => featuresRef.current?.scrollIntoView({ behavior: 'smooth' })}>
                    Learn More <ChevronDown size={16} />
                  </button>
                </div>

                {/* Status Indicators */}
                <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '20px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.75rem', fontFamily: 'monospace', color: '#34D399' }}>
                    <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#10B981', boxShadow: '0 0 8px #10B981', animation: 'pulse-glow 2s infinite' }} />
                    Core Online
                  </div>
                  <div style={{ width: '1px', height: '14px', background: 'rgba(255,255,255,0.1)' }} />
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.75rem', fontFamily: 'monospace', color: '#34D399' }}>
                    <Lock size={12} /> AES-256
                  </div>
                  <div style={{ width: '1px', height: '14px', background: 'rgba(255,255,255,0.1)' }} />
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.75rem', fontFamily: 'monospace', color: '#34D399' }}>
                    <Activity size={12} /> 14,204 Nodes
                  </div>
                </div>
              </motion.div>
            </div>
          </div>

          {/* Scroll hint */}
          <motion.div
            style={{ position: 'absolute', bottom: '32px', left: '50%', transform: 'translateX(-50%)', zIndex: 10 }}
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
          >
            <ChevronDown size={24} style={{ color: 'rgba(255,255,255,0.25)' }} />
          </motion.div>
        </section>

        {/* ====== TRUST STATS BAR ====== */}
        <section style={{ background: 'rgba(2, 6, 23, 0.4)', backdropFilter: 'blur(8px)', borderTop: '1px solid rgba(59, 130, 246, 0.1)', borderBottom: '1px solid rgba(59, 130, 246, 0.1)' }}>
          <div className="landing-container" style={{ paddingTop: '40px', paddingBottom: '40px' }}>
            <Reveal>
              <div className="landing-stats-grid">
                {stats.map((s, i) => (
                  <div key={i} style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 'clamp(1.5rem, 3vw, 2.2rem)', fontWeight: 800, fontFamily: 'monospace', color: '#60A5FA', marginBottom: '6px' }}>{s.value}</div>
                    <div style={{ fontSize: '0.8rem', color: '#64748B', fontFamily: 'monospace', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{s.label}</div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </section>

        {/* ====== FEATURES SECTION ====== */}
        <section ref={featuresRef} style={{ padding: '96px 0', background: 'linear-gradient(180deg, rgba(2,6,23,0.5) 0%, rgba(0,0,0,0.3) 100%)', backdropFilter: 'blur(12px)' }}>
          <div className="landing-container">
            <Reveal style={{ textAlign: 'center', marginBottom: '64px' }}>
              <div style={{ fontSize: '0.75rem', fontFamily: 'monospace', color: '#3B82F6', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: '12px' }}>
                ◆ CAPABILITIES
              </div>
              <h2 style={{ fontSize: 'clamp(1.8rem, 3vw, 2.5rem)', fontWeight: 700, letterSpacing: '-0.03em', marginBottom: '16px' }}>
                Enterprise-Grade Security
              </h2>
              <p style={{ fontSize: '1rem', color: '#64748B', maxWidth: '560px', margin: '0 auto', lineHeight: 1.7 }}>
                Built for institutions that demand uncompromising protection with elegant operational visibility.
              </p>
            </Reveal>

            <div className="landing-features-grid">
              {features.map((f, i) => (
                <Reveal key={i} delay={i * 0.08}>
                  <div className="feature-card">
                    <div style={{
                      width: '48px', height: '48px', borderRadius: '12px',
                      background: 'rgba(59, 130, 246, 0.08)', border: '1px solid rgba(59, 130, 246, 0.15)',
                      color: '#60A5FA',
                      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                      marginBottom: '16px',
                    }}>
                      {f.icon}
                    </div>
                    <h3 style={{ fontSize: '1.05rem', fontWeight: 600, marginBottom: '8px', color: '#E2E8F0' }}>{f.title}</h3>
                    <p style={{ fontSize: '0.85rem', color: '#64748B', lineHeight: 1.65, margin: 0 }}>{f.desc}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* ====== PLATFORM SECTION ====== */}
        <section style={{ padding: '96px 0', background: 'rgba(2, 6, 23, 0.6)', backdropFilter: 'blur(16px)' }}>
          <div className="landing-container">
            <div className="landing-platform-grid">
              <Reveal>
                <div style={{ fontSize: '0.75rem', fontFamily: 'monospace', color: '#3B82F6', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: '12px' }}>
                  ◆ PLATFORM
                </div>
                <h2 style={{ fontSize: 'clamp(1.8rem, 3vw, 2.5rem)', fontWeight: 700, letterSpacing: '-0.03em', marginBottom: '16px' }}>
                  One Dashboard. <br />
                  <span style={{ color: '#60A5FA' }}>Total Situational Awareness.</span>
                </h2>
                <p style={{ fontSize: '0.95rem', color: '#94A3B8', lineHeight: 1.8, marginBottom: '28px' }}>
                  TrustDesk consolidates security operations, community signals, incident triage, and forensic analysis into a single glass-panel interface. Designed for SOC operators, campus security teams, and institutional risk managers.
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  {[
                    { icon: <Cpu size={16} />, text: 'AI-powered threat classification & severity scoring' },
                    { icon: <Eye size={16} />, text: 'Live monitoring with geospatial incident mapping' },
                    { icon: <Globe size={16} />, text: 'Multi-zone, multi-campus federation support' },
                  ].map((item, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '0.9rem', color: '#CBD5E1' }}>
                      <span style={{ color: '#3B82F6' }}>{item.icon}</span>
                      {item.text}
                    </div>
                  ))}
                </div>
              </Reveal>

              <Reveal delay={0.2}>
                <div className="terminal-preview">
                  <div className="terminal-inner">
                    {/* Terminal chrome */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '24px' }}>
                      <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#EF4444' }} />
                      <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#F59E0B' }} />
                      <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#10B981' }} />
                      <span style={{ fontSize: '0.7rem', color: '#475569', marginLeft: '8px' }}>trustdesk://soc/dashboard</span>
                    </div>
                    {/* Terminal output */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                      <div style={{ color: '#475569' }}>$ trustdesk status --verbose</div>
                      <div style={{ color: '#34D399' }}>✓ Core systems operational</div>
                      <div style={{ color: '#34D399' }}>✓ Threat engine: 14,204 nodes active</div>
                      <div style={{ color: '#34D399' }}>✓ Encryption: AES-256-GCM</div>
                      <div style={{ color: '#F59E0B' }}>⚠ 3 incidents requiring triage</div>
                      <div style={{ color: '#EF4444' }}>✕ 1 critical alert: Zone B3</div>
                      <div style={{ color: '#475569', marginTop: '8px' }}>$ █</div>
                    </div>
                  </div>
                </div>
              </Reveal>
            </div>
          </div>
        </section>

        {/* ====== FINAL CTA ====== */}
        <section style={{ padding: '112px 0', background: 'linear-gradient(180deg, rgba(2, 6, 23, 0.4) 0%, rgba(0, 0, 0, 0.95) 100%)', backdropFilter: 'blur(16px)' }}>
          <div className="landing-container" style={{ textAlign: 'center' }}>
            <Reveal>
              <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '64px', height: '64px', borderRadius: '16px', background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.2)', marginBottom: '24px' }}>
                <Shield size={32} style={{ color: '#60A5FA' }} />
              </div>
              <h2 style={{ fontSize: 'clamp(1.8rem, 3vw, 2.5rem)', fontWeight: 700, letterSpacing: '-0.03em', marginBottom: '16px' }}>
                Ready to Secure Your Operation?
              </h2>
              <p style={{ fontSize: '1rem', color: '#64748B', marginBottom: '40px', lineHeight: 1.7, maxWidth: '440px', margin: '0 auto 40px auto' }}>
                Deploy TrustDesk and take command of your institution's security posture.
              </p>
              <button className="cta-btn-large" onClick={() => navigate('/app/dashboard')}>
                <Fingerprint size={24} style={{ color: '#60A5FA' }} />
                <span>LAUNCH CONSOLE</span>
                <ChevronRight size={20} style={{ color: '#60A5FA', opacity: 0.6 }} />
              </button>
            </Reveal>
          </div>
        </section>

        {/* ====== FOOTER ====== */}
        <footer style={{ borderTop: '1px solid rgba(255,255,255,0.05)', background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(20px)' }}>
          <div className="landing-container" style={{ paddingTop: '32px', paddingBottom: '32px' }}>
            <div className="landing-footer-inner">
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Shield size={18} style={{ color: '#3B82F6' }} />
                <span style={{ fontWeight: 700, fontSize: '0.9rem', letterSpacing: '-0.02em' }}>TRUST<span style={{ fontWeight: 300, color: '#60A5FA' }}>DESK</span></span>
              </div>
              <div style={{ fontSize: '0.75rem', color: '#475569', fontFamily: 'monospace' }}>
                © {new Date().getFullYear()} TrustDesk. Sovereign Security Operations.
              </div>
            </div>
          </div>
        </footer>
        </div>
      </div>
    </>
  );
};

export default Landing;
